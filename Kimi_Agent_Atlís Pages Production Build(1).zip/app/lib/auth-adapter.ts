import { db } from './db';

// Custom Prisma adapter for Auth.js
export function CustomPrismaAdapter() {
  return {
    async createUser(user: any) {
      return db.user.create({
        data: {
          email: user.email,
          name: user.name,
          image: user.image,
          emailVerified: user.emailVerified,
        },
      });
    },

    async getUser(id: string) {
      return db.user.findUnique({
        where: { id },
      });
    },

    async getUserByEmail(email: string) {
      return db.user.findUnique({
        where: { email },
      });
    },

    async getUserByAccount({ providerAccountId, provider }: { providerAccountId: string; provider: string }) {
      const account = await db.account.findFirst({
        where: {
          provider,
          providerAccountId,
        },
        include: {
          user: true,
        },
      });
      return account?.user || null;
    },

    async updateUser(user: any) {
      return db.user.update({
        where: { id: user.id },
        data: {
          name: user.name,
          email: user.email,
          image: user.image,
          emailVerified: user.emailVerified,
        },
      });
    },

    async deleteUser(userId: string) {
      await db.user.delete({
        where: { id: userId },
      });
    },

    async linkAccount(account: any) {
      return db.account.create({
        data: {
          userId: account.userId,
          type: account.type,
          provider: account.provider,
          providerAccountId: account.providerAccountId,
          refresh_token: account.refresh_token,
          access_token: account.access_token,
          expires_at: account.expires_at,
          token_type: account.token_type,
          scope: account.scope,
          id_token: account.id_token,
          session_state: account.session_state,
        },
      });
    },

    async unlinkAccount({ providerAccountId, provider }: { providerAccountId: string; provider: string }) {
      await db.account.deleteMany({
        where: {
          provider,
          providerAccountId,
        },
      });
    },

    async createSession(session: any) {
      return db.session.create({
        data: {
          userId: session.userId,
          sessionToken: session.sessionToken,
          expires: session.expires,
        },
      });
    },

    async getSessionAndUser(sessionToken: string) {
      const session = await db.session.findUnique({
        where: { sessionToken },
        include: { user: true },
      });
      if (!session) return null;
      return {
        session: {
          id: session.id,
          userId: session.userId,
          sessionToken: session.sessionToken,
          expires: session.expires,
        },
        user: session.user,
      };
    },

    async updateSession(session: any) {
      return db.session.update({
        where: { sessionToken: session.sessionToken },
        data: {
          expires: session.expires,
        },
      });
    },

    async deleteSession(sessionToken: string) {
      await db.session.deleteMany({
        where: { sessionToken },
      });
    },

    async createVerificationToken(token: any) {
      return db.verificationToken.create({
        data: {
          identifier: token.identifier,
          token: token.token,
          expires: token.expires,
        },
      });
    },

    async useVerificationToken({ identifier, token }: { identifier: string; token: string }) {
      try {
        const verificationToken = await db.verificationToken.delete({
          where: {
            identifier_token: {
              identifier,
              token,
            },
          },
        });
        return verificationToken;
      } catch (error) {
        return null;
      }
    },
  };
}
