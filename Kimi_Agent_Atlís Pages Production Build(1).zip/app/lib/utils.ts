import { type ClassValue, clsx } from "clsx";
import { twMerge } from "tailwind-merge";

export function cn(...inputs: ClassValue[]) {
  return twMerge(clsx(inputs));
}

export function formatDate(date: Date | string): string {
  return new Date(date).toLocaleDateString('en-US', {
    month: 'short',
    day: 'numeric',
    year: 'numeric',
  });
}

export function generateSlug(text: string): string {
  return text
    .toLowerCase()
    .replace(/[^a-z0-9]+/g, '-')
    .replace(/(^-|-$)/g, '');
}

export function isValidUsername(username: string): boolean {
  return /^[a-zA-Z0-9_-]{3,30}$/.test(username);
}

export function getPlanLimits(plan: string) {
  const plans = {
    free: {
      maxLinks: 5,
      customDomain: false,
      analytics: false,
      themes: ['dark', 'light'],
      removeBranding: false,
    },
    pro: {
      maxLinks: 20,
      customDomain: true,
      analytics: true,
      themes: ['dark', 'light', 'neon', 'minimal'],
      removeBranding: true,
    },
    ultra: {
      maxLinks: 100,
      customDomain: true,
      analytics: true,
      themes: ['dark', 'light', 'neon', 'minimal', 'gradient', 'custom'],
      removeBranding: true,
    },
  };
  
  return plans[plan as keyof typeof plans] || plans.free;
}
