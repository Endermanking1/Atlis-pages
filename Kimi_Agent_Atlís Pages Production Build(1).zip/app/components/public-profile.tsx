'use client';

import { motion } from 'framer-motion';
import { ExternalLink, Link2 } from 'lucide-react';
import Image from 'next/image';

interface Link {
  id: string;
  title: string;
  url: string;
  icon: string | null;
}

interface Profile {
  id: string;
  username: string;
  displayName: string | null;
  bio: string | null;
  avatar: string | null;
  theme: string;
  accentColor: string;
  animation: string;
  plan: string;
}

interface PublicProfileProps {
  profile: Profile;
  links: Link[];
}

const animations: Record<string, { initial?: any; animate?: any; transition?: any }> = {
  none: { initial: {}, animate: {}, transition: {} },
  fade: {
    initial: { opacity: 0 },
    animate: { opacity: 1 },
    transition: { duration: 0.5 },
  },
  slide: {
    initial: { opacity: 0, y: 30 },
    animate: { opacity: 1, y: 0 },
    transition: { duration: 0.5 },
  },
  bounce: {
    initial: { opacity: 0, scale: 0.8 },
    animate: { opacity: 1, scale: 1 },
    transition: { type: 'spring', stiffness: 200, damping: 15 },
  },
  pulse: {
    initial: { opacity: 0 },
    animate: { opacity: 1 },
    transition: { duration: 0.8 },
  },
};

const themes = {
  dark: {
    background: 'bg-zinc-950',
    card: 'bg-zinc-900/50',
    text: 'text-white',
    muted: 'text-zinc-400',
    border: 'border-zinc-800',
    button: 'bg-zinc-800 hover:bg-zinc-700',
    shadow: '',
  },
  light: {
    background: 'bg-gray-50',
    card: 'bg-white/80',
    text: 'text-gray-900',
    muted: 'text-gray-500',
    border: 'border-gray-200',
    button: 'bg-white hover:bg-gray-50 border border-gray-200 shadow-sm',
    shadow: 'shadow-lg',
  },
  neon: {
    background: 'bg-black',
    card: 'bg-zinc-900/30',
    text: 'text-white',
    muted: 'text-zinc-400',
    border: 'border-violet-500/30',
    button: 'bg-zinc-900 hover:bg-zinc-800 border border-violet-500/50',
    shadow: 'shadow-[0_0_30px_rgba(139,92,246,0.2)]',
  },
  minimal: {
    background: 'bg-white',
    card: 'bg-gray-50',
    text: 'text-gray-900',
    muted: 'text-gray-500',
    border: 'border-gray-100',
    button: 'bg-gray-100 hover:bg-gray-200',
    shadow: '',
  },
  gradient: {
    background: 'bg-gradient-to-br from-violet-950 via-purple-950 to-fuchsia-950',
    card: 'bg-white/10 backdrop-blur-sm',
    text: 'text-white',
    muted: 'text-white/60',
    border: 'border-white/10',
    button: 'bg-white/10 hover:bg-white/20 backdrop-blur-sm border border-white/20',
    shadow: '',
  },
  custom: {
    background: 'bg-zinc-950',
    card: 'bg-zinc-900/50',
    text: 'text-white',
    muted: 'text-zinc-400',
    border: 'border-zinc-800',
    button: 'bg-zinc-800 hover:bg-zinc-700',
    shadow: '',
  },
};

export function PublicProfile({ profile, links }: PublicProfileProps) {
  const theme = themes[profile.theme as keyof typeof themes] || themes.dark;
  const animation = animations[profile.animation as keyof typeof animations] || animations.fade;

  const handleLinkClick = async (linkId: string) => {
    // Track click (optional)
    try {
      await fetch('/api/links/click', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ linkId }),
      });
    } catch (error) {
      // Silently fail
    }
  };

  return (
    <div className={`min-h-screen ${theme.background} flex items-center justify-center p-4`}>
      <motion.div
        initial={animation.initial}
        animate={animation.animate}
        transition={animation.transition}
        className="w-full max-w-md"
      >
        <div className="flex flex-col items-center">
          {/* Avatar */}
          <motion.div
            initial={{ scale: 0 }}
            animate={{ scale: 1 }}
            transition={{ type: 'spring', stiffness: 200, damping: 15, delay: 0.1 }}
            className={`w-28 h-28 rounded-full ${theme.card} border-2 ${theme.border} flex items-center justify-center mb-6 overflow-hidden ${theme.shadow}`}
          >
            {profile.avatar ? (
              <Image
                src={profile.avatar}
                alt={profile.displayName || profile.username}
                width={112}
                height={112}
                className="w-full h-full object-cover"
              />
            ) : (
              <span className={`text-4xl font-bold ${theme.text}`}>
                {(profile.displayName || profile.username)[0].toUpperCase()}
              </span>
            )}
          </motion.div>

          {/* Name */}
          <motion.h1
            initial={{ opacity: 0, y: 10 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ delay: 0.2 }}
            className={`text-2xl font-bold ${theme.text} mb-1`}
          >
            {profile.displayName || profile.username}
          </motion.h1>

          {/* Username */}
          <motion.p
            initial={{ opacity: 0, y: 10 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ delay: 0.25 }}
            className={`text-sm ${theme.muted} mb-4`}
          >
            @{profile.username}
          </motion.p>

          {/* Bio */}
          {profile.bio && (
            <motion.p
              initial={{ opacity: 0, y: 10 }}
              animate={{ opacity: 1, y: 0 }}
              transition={{ delay: 0.3 }}
              className={`text-center ${theme.muted} mb-8 max-w-sm`}
            >
              {profile.bio}
            </motion.p>
          )}

          {/* Links */}
          <motion.div
            initial={{ opacity: 0 }}
            animate={{ opacity: 1 }}
            transition={{ delay: 0.4 }}
            className="w-full space-y-3"
          >
            {links.map((link, index) => (
              <motion.a
                key={link.id}
                href={link.url}
                target="_blank"
                rel="noopener noreferrer"
                initial={{ opacity: 0, y: 20 }}
                animate={{ opacity: 1, y: 0 }}
                transition={{ delay: 0.4 + index * 0.1 }}
                onClick={() => handleLinkClick(link.id)}
                className={`block w-full p-4 rounded-xl ${theme.button} transition-all duration-300 group relative overflow-hidden`}
                style={{
                  boxShadow: profile.theme === 'neon' ? `0 0 20px ${profile.accentColor}20` : undefined,
                }}
              >
                <div className="flex items-center justify-between relative z-10">
                  <span className={`font-medium ${theme.text}`}>{link.title}</span>
                  <ExternalLink className={`w-4 h-4 ${theme.muted} opacity-0 group-hover:opacity-100 transition-all transform group-hover:translate-x-1`} />
                </div>
                
                {/* Hover glow effect */}
                <div 
                  className="absolute inset-0 opacity-0 group-hover:opacity-100 transition-opacity duration-300"
                  style={{
                    background: `linear-gradient(135deg, ${profile.accentColor}10 0%, transparent 50%)`,
                  }}
                />
              </motion.a>
            ))}

            {links.length === 0 && (
              <div className={`text-center py-12 ${theme.muted}`}>
                <Link2 className="w-12 h-12 mx-auto mb-3 opacity-30" />
                <p>No links yet</p>
              </div>
            )}
          </motion.div>

          {/* Footer */}
          <motion.div
            initial={{ opacity: 0 }}
            animate={{ opacity: 1 }}
            transition={{ delay: 0.8 }}
            className="mt-12"
          >
            <a 
              href="https://pages.atlisai.org" 
              target="_blank" 
              rel="noopener noreferrer"
              className={`flex items-center gap-2 text-sm ${theme.muted} hover:${theme.text} transition-colors`}
            >
              <div className="w-5 h-5 rounded bg-gradient-to-br from-violet-500 to-fuchsia-500 flex items-center justify-center">
                <Link2 className="w-3 h-3 text-white" />
              </div>
              Atlís Pages
            </a>
          </motion.div>
        </div>
      </motion.div>
    </div>
  );
}
