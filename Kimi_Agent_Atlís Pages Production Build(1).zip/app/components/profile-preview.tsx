'use client';

import { motion } from 'framer-motion';
import { ExternalLink, Link as LinkIcon } from 'lucide-react';
import Image from 'next/image';

interface Link {
  id: string;
  title: string;
  url: string;
  icon: string | null;
}

interface Profile {
  id: string;
  username: string;
  displayName: string | null;
  bio: string | null;
  avatar: string | null;
  theme: string;
  accentColor: string;
  animation: string;
}

interface ProfilePreviewProps {
  profile: Profile | null;
  links: Link[];
}

const animations: Record<string, { initial?: any; animate?: any; transition?: any }> = {
  none: { initial: {}, animate: {}, transition: {} },
  fade: {
    initial: { opacity: 0 },
    animate: { opacity: 1 },
    transition: { duration: 0.3 },
  },
  slide: {
    initial: { opacity: 0, y: 20 },
    animate: { opacity: 1, y: 0 },
    transition: { duration: 0.3 },
  },
  bounce: {
    initial: { opacity: 0, scale: 0.8 },
    animate: { opacity: 1, scale: 1 },
    transition: { type: 'spring', stiffness: 300, damping: 20 },
  },
  pulse: {
    initial: { opacity: 0 },
    animate: { opacity: 1 },
    transition: { duration: 0.5 },
  },
};

const themes = {
  dark: {
    background: 'bg-zinc-950',
    card: 'bg-zinc-900/50',
    text: 'text-white',
    muted: 'text-zinc-400',
    border: 'border-zinc-800',
    button: 'bg-zinc-800 hover:bg-zinc-700',
  },
  light: {
    background: 'bg-gray-50',
    card: 'bg-white/80',
    text: 'text-gray-900',
    muted: 'text-gray-500',
    border: 'border-gray-200',
    button: 'bg-white hover:bg-gray-50 border border-gray-200',
  },
  neon: {
    background: 'bg-black',
    card: 'bg-zinc-900/30',
    text: 'text-white',
    muted: 'text-zinc-400',
    border: 'border-violet-500/30',
    button: 'bg-zinc-900 hover:bg-zinc-800 border border-violet-500/50',
  },
  minimal: {
    background: 'bg-white',
    card: 'bg-gray-50',
    text: 'text-gray-900',
    muted: 'text-gray-500',
    border: 'border-gray-100',
    button: 'bg-gray-100 hover:bg-gray-200',
  },
  gradient: {
    background: 'bg-gradient-to-br from-violet-950 via-purple-950 to-fuchsia-950',
    card: 'bg-white/10 backdrop-blur-sm',
    text: 'text-white',
    muted: 'text-white/60',
    border: 'border-white/10',
    button: 'bg-white/10 hover:bg-white/20 backdrop-blur-sm border border-white/20',
  },
  custom: {
    background: 'bg-zinc-950',
    card: 'bg-zinc-900/50',
    text: 'text-white',
    muted: 'text-zinc-400',
    border: 'border-zinc-800',
    button: 'bg-zinc-800 hover:bg-zinc-700',
  },
};

export function ProfilePreview({ profile, links }: ProfilePreviewProps) {
  const theme = themes[profile?.theme as keyof typeof themes] || themes.dark;
  const animation = animations[profile?.animation as keyof typeof animations] || animations.fade;

  return (
    <div className={`relative rounded-3xl overflow-hidden ${theme.background} min-h-[600px]`}>
      {/* Phone Frame */}
      <div className="absolute inset-0 border-8 border-zinc-800 rounded-3xl pointer-events-none z-10" />
      <div className="absolute top-0 left-1/2 -translate-x-1/2 w-32 h-6 bg-zinc-800 rounded-b-2xl z-10" />

      {/* Content */}
      <div className="h-full overflow-y-auto p-6 pt-10">
        <motion.div
          initial={animation.initial}
          animate={animation.animate}
          transition={animation.transition}
          className="flex flex-col items-center"
        >
          {/* Avatar */}
          <div className={`w-24 h-24 rounded-full ${theme.card} border-2 ${theme.border} flex items-center justify-center mb-4 overflow-hidden`}>
            {profile?.avatar ? (
              <Image
                src={profile.avatar}
                alt={profile.displayName || profile.username}
                width={96}
                height={96}
                className="w-full h-full object-cover"
              />
            ) : (
              <span className={`text-3xl font-bold ${theme.text}`}>
                {(profile?.displayName || profile?.username || '?')[0].toUpperCase()}
              </span>
            )}
          </div>

          {/* Name */}
          <h3 className={`text-xl font-bold ${theme.text}`}>
            {profile?.displayName || profile?.username || 'Your Name'}
          </h3>

          {/* Username */}
          <p className={`text-sm ${theme.muted} mb-2`}>
            @{profile?.username || 'username'}
          </p>

          {/* Bio */}
          {profile?.bio && (
            <p className={`text-sm ${theme.muted} text-center mb-6 max-w-xs`}>
              {profile.bio}
            </p>
          )}

          {/* Links */}
          <div className="w-full space-y-3 mt-4">
            {links.map((link, index) => (
              <motion.a
                key={link.id}
                href={link.url}
                target="_blank"
                rel="noopener noreferrer"
                initial={{ opacity: 0, y: 10 }}
                animate={{ opacity: 1, y: 0 }}
                transition={{ delay: index * 0.1 }}
                className={`block w-full p-4 rounded-xl ${theme.button} transition-all group`}
                style={{
                  boxShadow: profile?.theme === 'neon' ? `0 0 20px ${profile.accentColor}30` : undefined,
                }}
              >
                <div className="flex items-center justify-between">
                  <span className={`font-medium ${theme.text}`}>{link.title}</span>
                  <ExternalLink className={`w-4 h-4 ${theme.muted} opacity-0 group-hover:opacity-100 transition-opacity`} />
                </div>
              </motion.a>
            ))}

            {links.length === 0 && (
              <div className={`text-center py-8 ${theme.muted}`}>
                <LinkIcon className="w-8 h-8 mx-auto mb-2 opacity-50" />
                <p className="text-sm">No links yet</p>
              </div>
            )}
          </div>

          {/* Footer */}
          <div className={`mt-8 text-xs ${theme.muted}`}>
            Atlís Pages
          </div>
        </motion.div>
      </div>
    </div>
  );
}
