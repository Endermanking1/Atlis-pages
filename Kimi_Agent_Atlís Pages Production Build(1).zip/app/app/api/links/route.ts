import { NextResponse } from 'next/server';
import { getServerSession } from 'next-auth';
import { authOptions } from '@/lib/auth';
import { db } from '@/lib/db';
import { z } from 'zod';

const linkSchema = z.object({
  title: z.string().min(1).max(100),
  url: z.string().url(),
  icon: z.string().optional(),
});

// GET /api/links - Get all links for the current user
export async function GET() {
  try {
    const session = await getServerSession(authOptions);
    
    if (!session?.user?.id) {
      return NextResponse.json({ message: 'Unauthorized' }, { status: 401 });
    }

    const links = await db.link.findMany({
      where: { userId: session.user.id },
      orderBy: { order: 'asc' },
    });

    return NextResponse.json(links);
  } catch (error) {
    console.error('Error fetching links:', error);
    return NextResponse.json(
      { message: 'Internal server error' },
      { status: 500 }
    );
  }
}

// POST /api/links - Create a new link
export async function POST(req: Request) {
  try {
    const session = await getServerSession(authOptions);
    
    if (!session?.user?.id) {
      return NextResponse.json({ message: 'Unauthorized' }, { status: 401 });
    }

    const body = await req.json();
    const validated = linkSchema.safeParse(body);

    if (!validated.success) {
      return NextResponse.json(
        { message: 'Invalid input data' },
        { status: 400 }
      );
    }

    // Check plan limits
    const user = await db.user.findUnique({
      where: { id: session.user.id },
      include: { _count: { select: { links: true } } },
    });

    if (!user) {
      return NextResponse.json({ message: 'User not found' }, { status: 404 });
    }

    const planLimits = { free: 5, pro: 20, ultra: 100 };
    const maxLinks = planLimits[user.plan as keyof typeof planLimits] || 5;

    if (user._count.links >= maxLinks) {
      return NextResponse.json(
        { message: 'Link limit reached for your plan' },
        { status: 403 }
      );
    }

    // Get max order
    const maxOrder = await db.link.findFirst({
      where: { userId: session.user.id },
      orderBy: { order: 'desc' },
      select: { order: true },
    });

    const link = await db.link.create({
      data: {
        ...validated.data,
        userId: session.user.id,
        order: (maxOrder?.order || 0) + 1,
      },
    });

    return NextResponse.json(link, { status: 201 });
  } catch (error) {
    console.error('Error creating link:', error);
    return NextResponse.json(
      { message: 'Internal server error' },
      { status: 500 }
    );
  }
}
