import { NextResponse } from 'next/server';
import { getServerSession } from 'next-auth';
import { authOptions } from '@/lib/auth';
import { db } from '@/lib/db';
import { z } from 'zod';

const reorderSchema = z.object({
  links: z.array(
    z.object({
      id: z.string(),
      order: z.number(),
    })
  ),
});

// POST /api/links/reorder - Reorder links
export async function POST(req: Request) {
  try {
    const session = await getServerSession(authOptions);
    
    if (!session?.user?.id) {
      return NextResponse.json({ message: 'Unauthorized' }, { status: 401 });
    }

    const body = await req.json();
    const validated = reorderSchema.safeParse(body);

    if (!validated.success) {
      return NextResponse.json(
        { message: 'Invalid input data' },
        { status: 400 }
      );
    }

    // Update all links in a transaction
    await db.$transaction(
      validated.data.links.map((link) =>
        db.link.updateMany({
          where: { id: link.id, userId: session.user.id },
          data: { order: link.order },
        })
      )
    );

    return NextResponse.json({ message: 'Links reordered' });
  } catch (error) {
    console.error('Error reordering links:', error);
    return NextResponse.json(
      { message: 'Internal server error' },
      { status: 500 }
    );
  }
}
