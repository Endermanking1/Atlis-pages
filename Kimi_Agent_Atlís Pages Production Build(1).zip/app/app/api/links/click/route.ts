import { NextResponse } from 'next/server';
import { db } from '@/lib/db';
import { z } from 'zod';

const clickSchema = z.object({
  linkId: z.string(),
});

// POST /api/links/click - Track a link click
export async function POST(req: Request) {
  try {
    const body = await req.json();
    const validated = clickSchema.safeParse(body);

    if (!validated.success) {
      return NextResponse.json(
        { message: 'Invalid input data' },
        { status: 400 }
      );
    }

    const { linkId } = validated.data;

    // Increment click count
    await db.link.update({
      where: { id: linkId },
      data: {
        clicks: {
          increment: 1,
        },
      },
    });

    return NextResponse.json({ success: true });
  } catch (error) {
    console.error('Error tracking click:', error);
    // Don't return error to not affect user experience
    return NextResponse.json({ success: false });
  }
}
