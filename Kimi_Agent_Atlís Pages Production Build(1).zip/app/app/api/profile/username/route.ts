import { NextResponse } from 'next/server';
import { getServerSession } from 'next-auth';
import { authOptions } from '@/lib/auth';
import { db } from '@/lib/db';
import { z } from 'zod';

const usernameSchema = z.object({
  username: z
    .string()
    .min(3, 'Username must be at least 3 characters')
    .max(30, 'Username must be less than 30 characters')
    .regex(
      /^[a-zA-Z0-9_-]+$/,
      'Username can only contain letters, numbers, underscores, and hyphens'
    ),
});

// PATCH /api/profile/username - Update username
export async function PATCH(req: Request) {
  try {
    const session = await getServerSession(authOptions);
    
    if (!session?.user?.id) {
      return NextResponse.json({ message: 'Unauthorized' }, { status: 401 });
    }

    const body = await req.json();
    const validated = usernameSchema.safeParse(body);

    if (!validated.success) {
      const errorMessage = validated.error.issues[0]?.message || 'Invalid input';
      return NextResponse.json(
        { message: errorMessage },
        { status: 400 }
      );
    }

    const { username } = validated.data;

    // Check if username is already taken
    const existingUser = await db.user.findUnique({
      where: { username },
    });

    if (existingUser && existingUser.id !== session.user.id) {
      return NextResponse.json(
        { message: 'Username is already taken' },
        { status: 409 }
      );
    }

    // Update username
    await db.user.update({
      where: { id: session.user.id },
      data: { username },
    });

    return NextResponse.json({ message: 'Username updated', username });
  } catch (error) {
    console.error('Error updating username:', error);
    return NextResponse.json(
      { message: 'Internal server error' },
      { status: 500 }
    );
  }
}
