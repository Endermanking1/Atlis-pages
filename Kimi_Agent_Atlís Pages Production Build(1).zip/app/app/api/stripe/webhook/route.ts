import { NextResponse } from 'next/server';
import { stripe } from '@/lib/stripe';
import { db } from '@/lib/db';
import Stripe from 'stripe';

const webhookSecret = process.env.STRIPE_WEBHOOK_SECRET || '';

// POST /api/stripe/webhook - Handle Stripe webhooks
export async function POST(req: Request) {
  try {
    const payload = await req.text();
    const signature = req.headers.get('stripe-signature') || '';

    let event: Stripe.Event;

    try {
      event = stripe.webhooks.constructEvent(payload, signature, webhookSecret);
    } catch (err: any) {
      console.error('Webhook signature verification failed:', err.message);
      return NextResponse.json(
        { message: 'Webhook signature verification failed' },
        { status: 400 }
      );
    }

    // Handle events
    switch (event.type) {
      case 'checkout.session.completed': {
        const session = event.data.object as Stripe.Checkout.Session;
        
        // Get user ID from metadata
        const userId = session.metadata?.userId;
        const subscriptionId = session.subscription as string;

        if (userId && subscriptionId) {
          // Get subscription details
          const subscription = await stripe.subscriptions.retrieve(subscriptionId) as Stripe.Subscription;
          
          // Determine plan from price
          const priceId = subscription.items.data[0]?.price.id;
          let plan = 'pro';
          
          if (priceId === process.env.STRIPE_PRICE_ULTRA) {
            plan = 'ultra';
          }

          // Update user
          const periodEnd = (subscription as any).current_period_end;
          await db.user.update({
            where: { id: userId },
            data: {
              plan,
              stripeSubscriptionId: subscriptionId,
              planExpiresAt: periodEnd ? new Date(periodEnd * 1000) : null,
            },
          });
        }
        break;
      }

      case 'invoice.payment_succeeded': {
        const invoice = event.data.object as any;
        const subscriptionId = invoice.subscription as string;

        if (subscriptionId) {
          const subscription = await stripe.subscriptions.retrieve(subscriptionId) as Stripe.Subscription;
          
          // Find user by subscription ID
          const user = await db.user.findFirst({
            where: { stripeSubscriptionId: subscriptionId },
          });

          if (user) {
            // Update plan expiration
            const periodEnd = (subscription as any).current_period_end;
            await db.user.update({
              where: { id: user.id },
              data: {
                planExpiresAt: periodEnd ? new Date(periodEnd * 1000) : null,
              },
            });
          }
        }
        break;
      }

      case 'customer.subscription.deleted': {
        const subscription = event.data.object as Stripe.Subscription;
        const subscriptionId = subscription.id;

        // Find user by subscription ID
        const user = await db.user.findFirst({
          where: { stripeSubscriptionId: subscriptionId },
        });

        if (user) {
          // Downgrade to free
          await db.user.update({
            where: { id: user.id },
            data: {
              plan: 'free',
              stripeSubscriptionId: null,
              planExpiresAt: null,
            },
          });
        }
        break;
      }

      case 'customer.subscription.updated': {
        const subscription = event.data.object as Stripe.Subscription;
        
        if (subscription.cancel_at_period_end) {
          // Subscription will be canceled at period end
          const user = await db.user.findFirst({
            where: { stripeSubscriptionId: subscription.id },
          });

          if (user) {
            // Could send notification here
            console.log(`Subscription for user ${user.id} will cancel at period end`);
          }
        }
        break;
      }
    }

    return NextResponse.json({ received: true });
  } catch (error) {
    console.error('Error handling webhook:', error);
    return NextResponse.json(
      { message: 'Internal server error' },
      { status: 500 }
    );
  }
}

// Route segment config for body parsing
export const runtime = 'nodejs';
export const preferredRegion = 'iad1';
