'use client';

import { motion } from 'framer-motion';
import { Button } from '@/components/ui/button';
import { ArrowLeft, ExternalLink } from 'lucide-react';
import Link from 'next/link';
import { PublicProfile } from '@/components/public-profile';

// Demo profile data
const demoProfile = {
  id: 'demo',
  username: 'demo',
  displayName: 'Alex Creator',
  bio: 'Digital creator | Photographer | Travel enthusiast 🌍 Sharing my journey and favorite resources',
  avatar: null,
  theme: 'gradient',
  accentColor: '#8b5cf6',
  animation: 'slide',
  plan: 'pro',
  isPublic: true,
  showStats: true,
};

const demoLinks = [
  {
    id: '1',
    title: 'My Website',
    url: 'https://example.com',
    icon: null,
  },
  {
    id: '2',
    title: 'Instagram',
    url: 'https://instagram.com',
    icon: null,
  },
  {
    id: '3',
    title: 'YouTube Channel',
    url: 'https://youtube.com',
    icon: null,
  },
  {
    id: '4',
    title: 'Portfolio',
    url: 'https://portfolio.com',
    icon: null,
  },
  {
    id: '5',
    title: 'Contact Me',
    url: 'mailto:hello@example.com',
    icon: null,
  },
];

export default function DemoPage() {
  return (
    <div className="min-h-screen bg-background">
      {/* Header */}
      <header className="fixed top-0 left-0 right-0 z-50 glass-strong border-b border-white/10">
        <div className="container mx-auto px-4">
          <div className="flex items-center justify-between h-16">
            <Link href="/" className="flex items-center gap-2">
              <Button variant="ghost" size="sm" className="gap-2">
                <ArrowLeft className="w-4 h-4" />
                Back to Home
              </Button>
            </Link>
            
            <Link href="/signup">
              <Button size="sm">Create Your Page</Button>
            </Link>
          </div>
        </div>
      </header>

      {/* Demo Content */}
      <div className="pt-24 pb-12">
        <div className="container mx-auto px-4">
          <motion.div
            initial={{ opacity: 0, y: 20 }}
            animate={{ opacity: 1, y: 0 }}
            className="text-center mb-8"
          >
            <h1 className="text-3xl font-bold mb-2">Live Demo</h1>
            <p className="text-muted-foreground">
              This is how your page could look. Try it yourself!
            </p>
          </motion.div>

          {/* Profile Preview */}
          <motion.div
            initial={{ opacity: 0, scale: 0.95 }}
            animate={{ opacity: 1, scale: 1 }}
            transition={{ delay: 0.2 }}
            className="max-w-md mx-auto"
          >
            <PublicProfile profile={demoProfile} links={demoLinks} />
          </motion.div>

          {/* CTA */}
          <motion.div
            initial={{ opacity: 0, y: 20 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ delay: 0.4 }}
            className="text-center mt-12"
          >
            <p className="text-muted-foreground mb-4">
              Want your own page like this?
            </p>
            <Link href="/signup">
              <Button size="lg" className="gap-2">
                Get Started Free
                <ExternalLink className="w-4 h-4" />
              </Button>
            </Link>
          </motion.div>
        </div>
      </div>
    </div>
  );
}
