'use client';

import { useState, useEffect } from 'react';
import { useSession } from 'next-auth/react';
import { useRouter } from 'next/navigation';
import { motion } from 'framer-motion';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Label } from '@/components/ui/label';
import { Textarea } from '@/components/ui/textarea';
import {
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue,
} from '@/components/ui/select';
import {
  Tabs,
  TabsContent,
  TabsList,
  TabsTrigger,
} from '@/components/ui/tabs';
import {
  AlertDialog,
  AlertDialogAction,
  AlertDialogCancel,
  AlertDialogContent,
  AlertDialogDescription,
  AlertDialogFooter,
  AlertDialogHeader,
  AlertDialogTitle,
  AlertDialogTrigger,
} from '@/components/ui/alert-dialog';
import {
  Loader2,
  User,
  Palette,
  Crown,
  Trash2,
  Save,
  Check,
  AlertTriangle,
  Eye,
  EyeOff,
} from 'lucide-react';
import { toast } from 'sonner';
import { DashboardNav } from '@/components/dashboard-nav';
import { ProfilePreview } from '@/components/profile-preview';

const themes = [
  { value: 'dark', label: 'Dark', available: true },
  { value: 'light', label: 'Light', available: true },
  { value: 'neon', label: 'Neon', available: true },
  { value: 'minimal', label: 'Minimal', available: true },
  { value: 'gradient', label: 'Gradient', available: true },
  { value: 'custom', label: 'Custom (Ultra)', available: false },
];

const animations = [
  { value: 'none', label: 'None' },
  { value: 'fade', label: 'Fade' },
  { value: 'slide', label: 'Slide' },
  { value: 'bounce', label: 'Bounce' },
  { value: 'pulse', label: 'Pulse' },
];

export default function SettingsPage() {
  const { data: session, status, update } = useSession();
  const router = useRouter();
  
  const [isLoading, setIsLoading] = useState(true);
  const [isSaving, setIsSaving] = useState(false);
  const [profile, setProfile] = useState<any>(null);
  const [links, setLinks] = useState<any[]>([]);
  const [formData, setFormData] = useState({
    displayName: '',
    bio: '',
    username: '',
    theme: 'dark',
    accentColor: '#8b5cf6',
    animation: 'fade',
    isPublic: true,
    showStats: true,
  });

  useEffect(() => {
    if (status === 'unauthenticated') {
      router.push('/login');
    } else if (status === 'authenticated') {
      fetchData();
    }
  }, [status, router]);

  const fetchData = async () => {
    try {
      const [profileRes, linksRes] = await Promise.all([
        fetch('/api/profile'),
        fetch('/api/links'),
      ]);

      if (profileRes.ok) {
        const profileData = await profileRes.json();
        setProfile(profileData);
        setFormData({
          displayName: profileData.displayName || '',
          bio: profileData.bio || '',
          username: profileData.username || '',
          theme: profileData.theme || 'dark',
          accentColor: profileData.accentColor || '#8b5cf6',
          animation: profileData.animation || 'fade',
          isPublic: profileData.isPublic ?? true,
          showStats: profileData.showStats ?? true,
        });
      }

      if (linksRes.ok) {
        const linksData = await linksRes.json();
        setLinks(linksData.filter((l: any) => l.isActive));
      }
    } catch (error) {
      toast.error('Failed to load settings');
    } finally {
      setIsLoading(false);
    }
  };

  const handleSave = async () => {
    setIsSaving(true);
    try {
      const response = await fetch('/api/profile', {
        method: 'PATCH',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify(formData),
      });

      if (response.ok) {
        const updated = await response.json();
        setProfile(updated);
        await update({
          name: updated.displayName,
          username: updated.username,
        });
        toast.success('Settings saved');
      } else {
        const error = await response.json();
        toast.error(error.message || 'Failed to save settings');
      }
    } catch (error) {
      toast.error('Failed to save settings');
    } finally {
      setIsSaving(false);
    }
  };

  const handleDeleteAccount = async () => {
    try {
      const response = await fetch('/api/account', {
        method: 'DELETE',
      });

      if (response.ok) {
        toast.success('Account deleted');
        router.push('/');
      } else {
        toast.error('Failed to delete account');
      }
    } catch (error) {
      toast.error('Failed to delete account');
    }
  };

  const handleUsernameChange = async () => {
    if (formData.username === profile?.username) return;

    try {
      const response = await fetch('/api/profile/username', {
        method: 'PATCH',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ username: formData.username }),
      });

      if (response.ok) {
        toast.success('Username updated');
        await update({ username: formData.username });
      } else {
        const error = await response.json();
        toast.error(error.message || 'Failed to update username');
        setFormData({ ...formData, username: profile?.username || '' });
      }
    } catch (error) {
      toast.error('Failed to update username');
      setFormData({ ...formData, username: profile?.username || '' });
    }
  };

  if (status === 'loading' || isLoading) {
    return (
      <div className="min-h-screen flex items-center justify-center">
        <Loader2 className="w-8 h-8 animate-spin text-violet-500" />
      </div>
    );
  }

  if (!session) {
    return null;
  }

  const availableThemes = themes.filter(
    (t) => t.available || profile?.plan === 'ultra'
  );

  return (
    <div className="min-h-screen bg-background">
      <DashboardNav />
      
      <div className="container mx-auto px-4 py-8">
        <div className="max-w-4xl mx-auto">
          <h1 className="text-3xl font-bold mb-8">Settings</h1>
          
          <Tabs defaultValue="profile" className="space-y-8">
            <TabsList className="glass">
              <TabsTrigger value="profile" className="gap-2">
                <User className="w-4 h-4" />
                Profile
              </TabsTrigger>
              <TabsTrigger value="appearance" className="gap-2">
                <Palette className="w-4 h-4" />
                Appearance
              </TabsTrigger>
              <TabsTrigger value="plan" className="gap-2">
                <Crown className="w-4 h-4" />
                Plan
              </TabsTrigger>
              <TabsTrigger value="account" className="gap-2">
                <AlertTriangle className="w-4 h-4" />
                Account
              </TabsTrigger>
            </TabsList>

            {/* Profile Tab */}
            <TabsContent value="profile" className="space-y-6">
              <div className="glass rounded-2xl p-6 space-y-6">
                <h2 className="text-xl font-semibold">Profile Information</h2>
                
                <div className="space-y-4">
                  <div className="space-y-2">
                    <Label>Username</Label>
                    <div className="flex gap-2">
                      <Input
                        value={formData.username}
                        onChange={(e) =>
                          setFormData({ ...formData, username: e.target.value.toLowerCase() })
                        }
                        placeholder="username"
                      />
                      <Button
                        variant="outline"
                        onClick={handleUsernameChange}
                        disabled={formData.username === profile?.username}
                      >
                        Update
                      </Button>
                    </div>
                    <p className="text-sm text-muted-foreground">
                      Your page URL: pages.atlisai.org/{formData.username}
                    </p>
                  </div>

                  <div className="space-y-2">
                    <Label>Display Name</Label>
                    <Input
                      value={formData.displayName}
                      onChange={(e) =>
                        setFormData({ ...formData, displayName: e.target.value })
                      }
                      placeholder="Your Name"
                    />
                  </div>

                  <div className="space-y-2">
                    <Label>Bio</Label>
                    <Textarea
                      value={formData.bio}
                      onChange={(e) =>
                        setFormData({ ...formData, bio: e.target.value })
                      }
                      placeholder="Tell us about yourself"
                      rows={3}
                    />
                  </div>

                  <div className="flex items-center gap-4">
                    <div className="flex items-center gap-2">
                      <Button
                        variant={formData.isPublic ? 'default' : 'outline'}
                        size="sm"
                        onClick={() =>
                          setFormData({ ...formData, isPublic: true })
                        }
                        className="gap-2"
                      >
                        <Eye className="w-4 h-4" />
                        Public
                      </Button>
                      <Button
                        variant={!formData.isPublic ? 'default' : 'outline'}
                        size="sm"
                        onClick={() =>
                          setFormData({ ...formData, isPublic: false })
                        }
                        className="gap-2"
                      >
                        <EyeOff className="w-4 h-4" />
                        Private
                      </Button>
                    </div>
                  </div>
                </div>

                <Button
                  onClick={handleSave}
                  disabled={isSaving}
                  className="gap-2"
                >
                  {isSaving ? (
                    <Loader2 className="w-4 h-4 animate-spin" />
                  ) : (
                    <Save className="w-4 h-4" />
                  )}
                  Save Changes
                </Button>
              </div>
            </TabsContent>

            {/* Appearance Tab */}
            <TabsContent value="appearance" className="space-y-6">
              <div className="glass rounded-2xl p-6 space-y-6">
                <h2 className="text-xl font-semibold">Appearance</h2>
                
                <div className="space-y-4">
                  <div className="space-y-2">
                    <Label>Theme</Label>
                    <Select
                      value={formData.theme}
                      onValueChange={(value) =>
                        setFormData({ ...formData, theme: value })
                      }
                    >
                      <SelectTrigger>
                        <SelectValue />
                      </SelectTrigger>
                      <SelectContent>
                        {availableThemes.map((theme) => (
                          <SelectItem key={theme.value} value={theme.value}>
                            {theme.label}
                          </SelectItem>
                        ))}
                      </SelectContent>
                    </Select>
                  </div>

                  <div className="space-y-2">
                    <Label>Accent Color</Label>
                    <div className="flex gap-2">
                      <Input
                        type="color"
                        value={formData.accentColor}
                        onChange={(e) =>
                          setFormData({ ...formData, accentColor: e.target.value })
                        }
                        className="w-16 h-10 p-1"
                      />
                      <Input
                        value={formData.accentColor}
                        onChange={(e) =>
                          setFormData({ ...formData, accentColor: e.target.value })
                        }
                        placeholder="#8b5cf6"
                      />
                    </div>
                  </div>

                  <div className="space-y-2">
                    <Label>Animation</Label>
                    <Select
                      value={formData.animation}
                      onValueChange={(value) =>
                        setFormData({ ...formData, animation: value })
                      }
                    >
                      <SelectTrigger>
                        <SelectValue />
                      </SelectTrigger>
                      <SelectContent>
                        {animations.map((anim) => (
                          <SelectItem key={anim.value} value={anim.value}>
                            {anim.label}
                          </SelectItem>
                        ))}
                      </SelectContent>
                    </Select>
                  </div>
                </div>

                <Button
                  onClick={handleSave}
                  disabled={isSaving}
                  className="gap-2"
                >
                  {isSaving ? (
                    <Loader2 className="w-4 h-4 animate-spin" />
                  ) : (
                    <Save className="w-4 h-4" />
                  )}
                  Save Changes
                </Button>
              </div>

              {/* Preview */}
              <div>
                <h3 className="text-lg font-medium mb-4">Preview</h3>
                <ProfilePreview
                  profile={{ ...profile, ...formData }}
                  links={links}
                />
              </div>
            </TabsContent>

            {/* Plan Tab */}
            <TabsContent value="plan" className="space-y-6">
              <div className="glass rounded-2xl p-6">
                <div className="flex items-center justify-between mb-6">
                  <div>
                    <h2 className="text-xl font-semibold">Current Plan</h2>
                    <p className="text-muted-foreground">
                      You are on the{' '}
                      <span className="font-medium capitalize text-violet-400">
                        {profile?.plan}
                      </span>{' '}
                      plan
                    </p>
                  </div>
                  {profile?.plan !== 'ultra' && (
                    <Button className="gap-2">
                      <Crown className="w-4 h-4" />
                      Upgrade
                    </Button>
                  )}
                </div>

                <div className="grid md:grid-cols-3 gap-4">
                  {['free', 'pro', 'ultra'].map((plan) => (
                    <div
                      key={plan}
                      className={`p-4 rounded-xl border ${
                        profile?.plan === plan
                          ? 'border-violet-500 bg-violet-500/10'
                          : 'border-white/10'
                      }`}
                    >
                      <div className="flex items-center justify-between mb-2">
                        <span className="font-semibold capitalize">{plan}</span>
                        {profile?.plan === plan && (
                          <Check className="w-4 h-4 text-violet-400" />
                        )}
                      </div>
                      <p className="text-2xl font-bold">
                        ${plan === 'free' ? 0 : plan === 'pro' ? 9 : 29}
                        <span className="text-sm font-normal text-muted-foreground">
                          /mo
                        </span>
                      </p>
                    </div>
                  ))}
                </div>
              </div>
            </TabsContent>

            {/* Account Tab */}
            <TabsContent value="account" className="space-y-6">
              <div className="glass rounded-2xl p-6 border-red-500/20">
                <h2 className="text-xl font-semibold text-red-400 mb-4">
                  Danger Zone
                </h2>
                
                <div className="space-y-4">
                  <div className="flex items-center justify-between">
                    <div>
                      <p className="font-medium">Delete Account</p>
                      <p className="text-sm text-muted-foreground">
                        Permanently delete your account and all data
                      </p>
                    </div>
                    
                    <AlertDialog>
                      <AlertDialogTrigger asChild>
                        <Button variant="destructive" className="gap-2">
                          <Trash2 className="w-4 h-4" />
                          Delete
                        </Button>
                      </AlertDialogTrigger>
                      <AlertDialogContent>
                        <AlertDialogHeader>
                          <AlertDialogTitle>
                            Are you absolutely sure?
                          </AlertDialogTitle>
                          <AlertDialogDescription>
                            This action cannot be undone. This will permanently
                            delete your account and remove all your data from our
                            servers.
                          </AlertDialogDescription>
                        </AlertDialogHeader>
                        <AlertDialogFooter>
                          <AlertDialogCancel>Cancel</AlertDialogCancel>
                          <AlertDialogAction
                            onClick={handleDeleteAccount}
                            className="bg-destructive text-destructive-foreground"
                          >
                            Delete Account
                          </AlertDialogAction>
                        </AlertDialogFooter>
                      </AlertDialogContent>
                    </AlertDialog>
                  </div>
                </div>
              </div>
            </TabsContent>
          </Tabs>
        </div>
      </div>
    </div>
  );
}
