'use client';

import { useState, useEffect } from 'react';
import { useSession } from 'next-auth/react';
import { useRouter } from 'next/navigation';
import { motion, AnimatePresence, Reorder } from 'framer-motion';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Label } from '@/components/ui/label';
import {
  Dialog,
  DialogContent,
  DialogHeader,
  DialogTitle,
  DialogTrigger,
} from '@/components/ui/dialog';
import {
  DropdownMenu,
  DropdownMenuContent,
  DropdownMenuItem,
  DropdownMenuTrigger,
} from '@/components/ui/dropdown-menu';
import {
  Plus,
  Link as LinkIcon,
  ExternalLink,
  Settings,
  Trash2,
  GripVertical,
  Loader2,
  Crown,
  BarChart3,
  Palette,
  Share2,
  MoreVertical,
  Edit,
  Eye,
  EyeOff,
} from 'lucide-react';
import Link from 'next/link';
import { toast } from 'sonner';
import { ProfilePreview } from '@/components/profile-preview';
import { DashboardNav } from '@/components/dashboard-nav';

interface Link {
  id: string;
  title: string;
  url: string;
  icon: string | null;
  order: number;
  isActive: boolean;
  clicks: number;
}

interface UserProfile {
  id: string;
  username: string;
  displayName: string | null;
  bio: string | null;
  avatar: string | null;
  theme: string;
  accentColor: string;
  animation: string;
  plan: string;
}

export default function DashboardPage() {
  const { data: session, status } = useSession();
  const router = useRouter();
  
  const [links, setLinks] = useState<Link[]>([]);
  const [profile, setProfile] = useState<UserProfile | null>(null);
  const [isLoading, setIsLoading] = useState(true);
  const [isAddingLink, setIsAddingLink] = useState(false);
  const [editingLink, setEditingLink] = useState<Link | null>(null);
  const [newLink, setNewLink] = useState({ title: '', url: '' });

  useEffect(() => {
    if (status === 'unauthenticated') {
      router.push('/login');
    } else if (status === 'authenticated') {
      fetchData();
    }
  }, [status, router]);

  const fetchData = async () => {
    try {
      const [linksRes, profileRes] = await Promise.all([
        fetch('/api/links'),
        fetch('/api/profile'),
      ]);

      if (linksRes.ok) {
        const linksData = await linksRes.json();
        setLinks(linksData);
      }

      if (profileRes.ok) {
        const profileData = await profileRes.json();
        setProfile(profileData);
      }
    } catch (error) {
      toast.error('Failed to load data');
    } finally {
      setIsLoading(false);
    }
  };

  const handleAddLink = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!newLink.title || !newLink.url) return;

    try {
      const response = await fetch('/api/links', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify(newLink),
      });

      if (response.ok) {
        const link = await response.json();
        setLinks([...links, link]);
        setNewLink({ title: '', url: '' });
        setIsAddingLink(false);
        toast.success('Link added');
      } else {
        const error = await response.json();
        toast.error(error.message || 'Failed to add link');
      }
    } catch (error) {
      toast.error('Failed to add link');
    }
  };

  const handleUpdateLink = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!editingLink) return;

    try {
      const response = await fetch(`/api/links/${editingLink.id}`, {
        method: 'PATCH',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({
          title: editingLink.title,
          url: editingLink.url,
        }),
      });

      if (response.ok) {
        const updated = await response.json();
        setLinks(links.map((l) => (l.id === updated.id ? updated : l)));
        setEditingLink(null);
        toast.success('Link updated');
      } else {
        toast.error('Failed to update link');
      }
    } catch (error) {
      toast.error('Failed to update link');
    }
  };

  const handleDeleteLink = async (id: string) => {
    try {
      const response = await fetch(`/api/links/${id}`, {
        method: 'DELETE',
      });

      if (response.ok) {
        setLinks(links.filter((l) => l.id !== id));
        toast.success('Link deleted');
      } else {
        toast.error('Failed to delete link');
      }
    } catch (error) {
      toast.error('Failed to delete link');
    }
  };

  const handleToggleLink = async (id: string, isActive: boolean) => {
    try {
      const response = await fetch(`/api/links/${id}`, {
        method: 'PATCH',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ isActive: !isActive }),
      });

      if (response.ok) {
        const updated = await response.json();
        setLinks(links.map((l) => (l.id === updated.id ? updated : l)));
      }
    } catch (error) {
      toast.error('Failed to toggle link');
    }
  };

  const handleReorder = async (newOrder: Link[]) => {
    setLinks(newOrder);
    
    try {
      await fetch('/api/links/reorder', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({
          links: newOrder.map((l, i) => ({ id: l.id, order: i })),
        }),
      });
    } catch (error) {
      toast.error('Failed to save order');
    }
  };

  if (status === 'loading' || isLoading) {
    return (
      <div className="min-h-screen flex items-center justify-center">
        <Loader2 className="w-8 h-8 animate-spin text-violet-500" />
      </div>
    );
  }

  if (!session) {
    return null;
  }

  const planLimits = {
    free: 5,
    pro: 20,
    ultra: 100,
  };

  const maxLinks = planLimits[profile?.plan as keyof typeof planLimits] || 5;
  const canAddMore = links.length < maxLinks;

  return (
    <div className="min-h-screen bg-background">
      <DashboardNav />
      
      <div className="container mx-auto px-4 py-8">
        <div className="grid lg:grid-cols-2 gap-8">
          {/* Left Column - Editor */}
          <div className="space-y-6">
            {/* Header */}
            <div className="flex items-center justify-between">
              <div>
                <h1 className="text-2xl font-bold">Your Links</h1>
                <p className="text-sm text-muted-foreground">
                  {links.length} / {maxLinks === 100 ? 'Unlimited' : maxLinks} links
                </p>
              </div>
              <div className="flex gap-2">
                <Link href={`/${profile?.username}`} target="_blank">
                  <Button variant="outline" size="sm" className="gap-2">
                    <ExternalLink className="w-4 h-4" />
                    View Page
                  </Button>
                </Link>
                <Dialog open={isAddingLink} onOpenChange={setIsAddingLink}>
                  <DialogTrigger asChild>
                    <Button size="sm" className="gap-2" disabled={!canAddMore}>
                      <Plus className="w-4 h-4" />
                      Add Link
                    </Button>
                  </DialogTrigger>
                  <DialogContent>
                    <DialogHeader>
                      <DialogTitle>Add New Link</DialogTitle>
                    </DialogHeader>
                    <form onSubmit={handleAddLink} className="space-y-4">
                      <div className="space-y-2">
                        <Label>Title</Label>
                        <Input
                          placeholder="My Website"
                          value={newLink.title}
                          onChange={(e) =>
                            setNewLink({ ...newLink, title: e.target.value })
                          }
                        />
                      </div>
                      <div className="space-y-2">
                        <Label>URL</Label>
                        <Input
                          placeholder="https://example.com"
                          value={newLink.url}
                          onChange={(e) =>
                            setNewLink({ ...newLink, url: e.target.value })
                          }
                        />
                      </div>
                      <Button type="submit" className="w-full">
                        Add Link
                      </Button>
                    </form>
                  </DialogContent>
                </Dialog>
              </div>
            </div>

            {/* Links List */}
            <div className="space-y-3">
              <Reorder.Group
                axis="y"
                values={links}
                onReorder={handleReorder}
                className="space-y-3"
              >
                <AnimatePresence>
                  {links.map((link) => (
                    <Reorder.Item
                      key={link.id}
                      value={link}
                      className="glass rounded-xl p-4"
                    >
                      <motion.div
                        layout
                        initial={{ opacity: 0 }}
                        animate={{ opacity: 1 }}
                        exit={{ opacity: 0 }}
                        className="flex items-center gap-3"
                      >
                        <GripVertical className="w-5 h-5 text-muted-foreground cursor-grab" />
                        
                        <div className="flex-1 min-w-0">
                          <p className="font-medium truncate">{link.title}</p>
                          <p className="text-sm text-muted-foreground truncate">
                            {link.url}
                          </p>
                        </div>

                        <div className="flex items-center gap-2">
                          <span className="text-xs text-muted-foreground">
                            {link.clicks} clicks
                          </span>
                          
                          <Button
                            variant="ghost"
                            size="icon"
                            className="h-8 w-8"
                            onClick={() => handleToggleLink(link.id, link.isActive)}
                          >
                            {link.isActive ? (
                              <Eye className="w-4 h-4" />
                            ) : (
                              <EyeOff className="w-4 h-4 text-muted-foreground" />
                            )}
                          </Button>

                          <Dialog>
                            <DialogTrigger asChild>
                              <Button
                                variant="ghost"
                                size="icon"
                                className="h-8 w-8"
                                onClick={() => setEditingLink(link)}
                              >
                                <Edit className="w-4 h-4" />
                              </Button>
                            </DialogTrigger>
                            <DialogContent>
                              <DialogHeader>
                                <DialogTitle>Edit Link</DialogTitle>
                              </DialogHeader>
                              <form onSubmit={handleUpdateLink} className="space-y-4">
                                <div className="space-y-2">
                                  <Label>Title</Label>
                                  <Input
                                    value={editingLink?.title || ''}
                                    onChange={(e) =>
                                      setEditingLink(
                                        editingLink
                                          ? { ...editingLink, title: e.target.value }
                                          : null
                                      )
                                    }
                                  />
                                </div>
                                <div className="space-y-2">
                                  <Label>URL</Label>
                                  <Input
                                    value={editingLink?.url || ''}
                                    onChange={(e) =>
                                      setEditingLink(
                                        editingLink
                                          ? { ...editingLink, url: e.target.value }
                                          : null
                                      )
                                    }
                                  />
                                </div>
                                <Button type="submit" className="w-full">
                                  Save Changes
                                </Button>
                              </form>
                            </DialogContent>
                          </Dialog>

                          <Button
                            variant="ghost"
                            size="icon"
                            className="h-8 w-8 text-destructive"
                            onClick={() => handleDeleteLink(link.id)}
                          >
                            <Trash2 className="w-4 h-4" />
                          </Button>
                        </div>
                      </motion.div>
                    </Reorder.Item>
                  ))}
                </AnimatePresence>
              </Reorder.Group>

              {links.length === 0 && (
                <div className="text-center py-12 glass rounded-xl">
                  <LinkIcon className="w-12 h-12 text-muted-foreground mx-auto mb-4" />
                  <p className="text-muted-foreground">No links yet</p>
                  <p className="text-sm text-muted-foreground">
                    Add your first link to get started
                  </p>
                </div>
              )}
            </div>

            {/* Quick Actions */}
            <div className="grid grid-cols-2 gap-4">
              <Link href="/settings">
                <div className="glass rounded-xl p-4 hover:glass-strong transition-colors cursor-pointer">
                  <Palette className="w-6 h-6 text-violet-400 mb-2" />
                  <p className="font-medium">Appearance</p>
                  <p className="text-sm text-muted-foreground">
                    Customize your theme
                  </p>
                </div>
              </Link>
              <Link href="/settings?tab=plan">
                <div className="glass rounded-xl p-4 hover:glass-strong transition-colors cursor-pointer">
                  <Crown className="w-6 h-6 text-amber-400 mb-2" />
                  <p className="font-medium">Plan</p>
                  <p className="text-sm text-muted-foreground capitalize">
                    {profile?.plan} plan
                  </p>
                </div>
              </Link>
            </div>
          </div>

          {/* Right Column - Preview */}
          <div className="lg:sticky lg:top-24 h-fit">
            <div className="mb-4 flex items-center justify-between">
              <h2 className="text-lg font-medium">Live Preview</h2>
              <div className="flex items-center gap-2 text-sm text-muted-foreground">
                <div className="w-2 h-2 rounded-full bg-green-500 animate-pulse" />
                Auto-updating
              </div>
            </div>
            <ProfilePreview profile={profile} links={links.filter((l) => l.isActive)} />
          </div>
        </div>
      </div>
    </div>
  );
}
