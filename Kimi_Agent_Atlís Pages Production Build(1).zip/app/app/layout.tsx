import type { Metadata } from 'next';
import { Inter } from 'next/font/google';
import './globals.css';
import { Providers } from '@/components/providers';
import { Toaster } from '@/components/ui/sonner';

const inter = Inter({ subsets: ['latin'] });

export const metadata: Metadata = {
  title: 'Atlís Pages - Your Link in Bio',
  description: 'Create a beautiful link-in-bio page in minutes. Atlís Pages is the modern way to share your links.',
  keywords: ['link in bio', 'bio link', 'linktree alternative', 'social links'],
  authors: [{ name: 'Atlís Pages' }],
  openGraph: {
    title: 'Atlís Pages - Your Link in Bio',
    description: 'Create a beautiful link-in-bio page in minutes.',
    type: 'website',
    url: 'https://pages.atlisai.org',
  },
  twitter: {
    card: 'summary_large_image',
    title: 'Atlís Pages - Your Link in Bio',
    description: 'Create a beautiful link-in-bio page in minutes.',
  },
};

export default function RootLayout({
  children,
}: {
  children: React.ReactNode;
}) {
  return (
    <html lang="en" suppressHydrationWarning>
      <body className={inter.className}>
        <Providers>
          {children}
          <Toaster position="bottom-right" />
        </Providers>
      </body>
    </html>
  );
}
