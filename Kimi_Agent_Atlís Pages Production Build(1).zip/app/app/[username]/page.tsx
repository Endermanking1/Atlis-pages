import { notFound } from 'next/navigation';
import { Metadata } from 'next';
import { db } from '@/lib/db';
import { PublicProfile } from '@/components/public-profile';

interface ProfilePageProps {
  params: { username: string };
}

export async function generateMetadata({ params }: ProfilePageProps): Promise<Metadata> {
  const user = await db.user.findUnique({
    where: { username: params.username },
    select: {
      displayName: true,
      bio: true,
      avatar: true,
    },
  });

  if (!user) {
    return {
      title: 'Page Not Found - Atlís Pages',
    };
  }

  const displayName = user.displayName || params.username;

  return {
    title: `${displayName} - Atlís Pages`,
    description: user.bio || `Check out ${displayName}'s links`,
    openGraph: {
      title: `${displayName} - Atlís Pages`,
      description: user.bio || `Check out ${displayName}'s links`,
      images: user.avatar ? [user.avatar] : undefined,
    },
    twitter: {
      card: 'summary_large_image',
      title: `${displayName} - Atlís Pages`,
      description: user.bio || `Check out ${displayName}'s links`,
      images: user.avatar ? [user.avatar] : undefined,
    },
  };
}

export default async function ProfilePage({ params }: ProfilePageProps) {
  const user = await db.user.findUnique({
    where: { username: params.username },
    select: {
      id: true,
      username: true,
      displayName: true,
      bio: true,
      avatar: true,
      theme: true,
      accentColor: true,
      animation: true,
      isPublic: true,
      showStats: true,
      plan: true,
    },
  });

  if (!user) {
    notFound();
  }

  // Check if profile is public
  if (!user.isPublic) {
    notFound();
  }

  // Get active links
  const links = await db.link.findMany({
    where: {
      userId: user.id,
      isActive: true,
    },
    orderBy: { order: 'asc' },
    select: {
      id: true,
      title: true,
      url: true,
      icon: true,
    },
  });

  // Increment link clicks (optional analytics)
  // This could be done via a separate API call for better tracking

  // Ensure username is not null for the profile component
  const profile = {
    ...user,
    username: user.username || params.username,
  };

  return (
    <PublicProfile
      profile={profile}
      links={links}
    />
  );
}

// Generate static params for common usernames (optional optimization)
export async function generateStaticParams() {
  // In production, you might want to pre-render popular profiles
  return [];
}
