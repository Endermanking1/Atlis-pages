# Atlís Pages

A full-stack, production-ready link-in-bio platform built with Next.js, Prisma, PostgreSQL, and Stripe.

## Features

- **Authentication**: Email/password + OAuth (Google, GitHub) via Auth.js
- **Link Management**: Create, edit, delete, and reorder links with drag-and-drop
- **Customizable Themes**: Dark, light, neon, minimal, gradient themes
- **Real-time Preview**: See changes instantly as you edit
- **Public Profiles**: Each user gets a unique URL at `pages.atlisai.org/username`
- **Stripe Payments**: Full subscription management (Free, Pro, Ultra plans)
- **Responsive Design**: Works on all devices
- **SEO Optimized**: Dynamic metadata for each profile

## Tech Stack

- **Framework**: Next.js 14 (App Router)
- **Language**: TypeScript
- **Styling**: Tailwind CSS
- **UI Components**: shadcn/ui
- **Animations**: Framer Motion
- **Database**: PostgreSQL
- **ORM**: Prisma
- **Auth**: Auth.js (NextAuth)
- **Payments**: Stripe

## Getting Started

### Prerequisites

- Node.js 18+
- PostgreSQL database
- Stripe account (for payments)
- OAuth credentials (Google, GitHub - optional)

### Installation

1. Clone the repository:
```bash
git clone https://github.com/yourusername/atlispages.git
cd atlispages
```

2. Install dependencies:
```bash
npm install
```

3. Set up environment variables:
```bash
cp .env.example .env.local
```

4. Update `.env.local` with your credentials:
```env
# Database
DATABASE_URL="postgresql://user:password@localhost:5432/atlispages?schema=public"

# NextAuth
NEXTAUTH_URL="http://localhost:3000"
NEXTAUTH_SECRET="your-super-secret-key"

# OAuth (optional)
GOOGLE_CLIENT_ID=""
GOOGLE_CLIENT_SECRET=""
GITHUB_CLIENT_ID=""
GITHUB_CLIENT_SECRET=""

# Stripe
STRIPE_PUBLISHABLE_KEY="pk_test_..."
STRIPE_SECRET_KEY="sk_test_..."
STRIPE_WEBHOOK_SECRET="whsec_..."
STRIPE_PRICE_PRO="price_..."
STRIPE_PRICE_ULTRA="price_..."

# App
APP_URL="http://localhost:3000"
```

5. Set up the database:
```bash
npx prisma generate
npx prisma db push
```

6. Run the development server:
```bash
npm run dev
```

7. Open [http://localhost:3000](http://localhost:3000) in your browser.

### Stripe Webhook Setup (Local Development)

1. Install Stripe CLI: https://stripe.com/docs/stripe-cli

2. Login to Stripe:
```bash
stripe login
```

3. Forward webhooks to your local server:
```bash
stripe listen --forward-to localhost:3000/api/stripe/webhook
```

4. Copy the webhook signing secret to your `.env.local` file.

## Project Structure

```
app/
├── (auth)/              # Auth group routes
│   ├── login/           # Login page
│   └── signup/          # Signup page
├── (dashboard)/         # Dashboard group routes
│   ├── dashboard/       # Main dashboard
│   └── settings/        # User settings
├── (marketing)/         # Marketing group routes
│   └── demo/            # Demo page
├── [username]/          # Public profile page
├── api/                 # API routes
│   ├── auth/            # Auth.js API
│   ├── links/           # Links API
│   ├── profile/         # Profile API
│   └── stripe/          # Stripe API
├── globals.css          # Global styles
├── layout.tsx           # Root layout
└── page.tsx             # Homepage

components/              # React components
├── ui/                  # shadcn/ui components
├── animated-background.tsx
├── dashboard-nav.tsx
├── feature-card.tsx
├── navbar.tsx
├── pricing-card.tsx
├── profile-preview.tsx
├── providers.tsx
└── public-profile.tsx

lib/                     # Utility functions
├── auth.ts              # Auth.js configuration
├── db.ts                # Prisma client
├── stripe.ts            # Stripe utilities
├── utils.ts             # Helper functions
└── validations.ts       # Zod schemas

prisma/
└── schema.prisma        # Database schema
```

## API Routes

### Authentication
- `POST /api/auth/[...nextauth]` - NextAuth.js endpoints
- `POST /api/auth/register` - User registration

### Links
- `GET /api/links` - Get all links
- `POST /api/links` - Create a new link
- `PATCH /api/links/[id]` - Update a link
- `DELETE /api/links/[id]` - Delete a link
- `POST /api/links/reorder` - Reorder links
- `POST /api/links/click` - Track link click

### Profile
- `GET /api/profile` - Get current user's profile
- `PATCH /api/profile` - Update profile
- `PATCH /api/profile/username` - Update username

### Account
- `DELETE /api/account` - Delete account

### Stripe
- `POST /api/stripe/checkout` - Create checkout session
- `POST /api/stripe/portal` - Create billing portal session
- `POST /api/stripe/webhook` - Stripe webhook handler

## Database Schema

### User
- `id`: String (CUID)
- `email`: String (unique)
- `username`: String (unique)
- `password`: String (hashed)
- `displayName`: String
- `bio`: String
- `avatar`: String
- `theme`: String
- `accentColor`: String
- `animation`: String
- `plan`: String (free/pro/ultra)
- `stripeCustomerId`: String
- `stripeSubscriptionId`: String
- `isPublic`: Boolean
- `showStats`: Boolean

### Link
- `id`: String (CUID)
- `userId`: String
- `title`: String
- `url`: String
- `icon`: String
- `order`: Int
- `isActive`: Boolean
- `clicks`: Int

## Deployment

### Vercel (Recommended)

1. Push your code to GitHub

2. Import project in Vercel

3. Add environment variables in Vercel dashboard

4. Deploy!

### Database Setup

For production, use a managed PostgreSQL service:
- Vercel Postgres
- Railway
- Supabase
- AWS RDS

### Stripe Webhook (Production)

1. Go to Stripe Dashboard → Developers → Webhooks

2. Add endpoint: `https://yourdomain.com/api/stripe/webhook`

3. Select events:
   - `checkout.session.completed`
   - `invoice.payment_succeeded`
   - `customer.subscription.deleted`
   - `customer.subscription.updated`

4. Copy signing secret to environment variables

## Plan Limits

| Feature | Free | Pro ($9/mo) | Ultra ($29/mo) |
|---------|------|-------------|----------------|
| Links | 5 | 20 | Unlimited |
| Themes | 2 | 4 | 6 + Custom |
| Custom Domain | ❌ | ✅ | ✅ |
| Analytics | Basic | Advanced | Full |
| Remove Branding | ❌ | ✅ | ✅ |
| API Access | ❌ | ❌ | ✅ |

## Security

- Passwords are hashed using SHA-256
- All API routes are protected with authentication
- Input validation with Zod
- CSRF protection via Auth.js
- Secure session management

## License

MIT License - feel free to use this project for your own purposes.

## Support

For support, email support@atlisai.org or open an issue on GitHub.
